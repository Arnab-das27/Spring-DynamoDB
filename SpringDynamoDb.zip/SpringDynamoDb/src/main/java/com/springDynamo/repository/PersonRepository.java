package com.springDynamo.repository;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.springDynamo.entity.Person;

@Repository
public class PersonRepository {
	
	@Autowired
	public DynamoDBMapper dynamoDBMapper;
	
	public Person save(Person person) {
		dynamoDBMapper.save(person);
		return person;
	}
	
	public Person findById(String personId) {
		return dynamoDBMapper.load(Person.class,personId);
	}
	
	public List<Person> findAll(){
		return dynamoDBMapper.scan(Person.class, new DynamoDBScanExpression());
	}
	
	public String update(String personId,Person person) {
		dynamoDBMapper.save(person, new DynamoDBSaveExpression()
		.withExpectedEntry("personId", 
				new ExpectedAttributeValue(
						new AttributeValue().withS(personId)
						)));
		return personId;
	}
	
	public String delete(String personId) {
		
		Person person = dynamoDBMapper.load(Person.class,personId);
		dynamoDBMapper.delete(person);
		return "Person deleted Successfully:: "+personId;
	}
}