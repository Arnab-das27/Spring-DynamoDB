package com.springDynamo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springDynamo.entity.Person;
import com.springDynamo.repository.PersonRepository;

@RestController
@RequestMapping("/persons")
public class PersonController {
	
	@Autowired
	private PersonRepository personRepository;
	
	@PostMapping
	public Person save(@RequestBody Person person) {		
		return personRepository.save(person);
	}
	
	@GetMapping("/{personId}")
	public Person findById(@PathVariable(value = "personId") String personId) {
		return personRepository.findById(personId);
	}
	
	@GetMapping
	public List<Person> findAll(){
		return personRepository.findAll();
	}
	
	@PutMapping("/{personId}")
	public String update(@PathVariable(value = "personId") String personId,
			@RequestBody Person person) {
				return personRepository.update(personId, person);
	}
	
	@DeleteMapping("/{personId}")
	public String delete(@PathVariable(value = "personId") String personId) {
		return personRepository.delete(personId);
	}
}